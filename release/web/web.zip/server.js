const express = require('express');
const serveStatic = require('serve-static');
const path = require('path');
const app = express();
const fs = require('fs');
const zlib = require('zlib');

// Middleware to ensure Content-Encoding is set for .gz files
app.use((req, res, next) => {
  // If the requested file is a .gz file
  if (req.url.endsWith('.gz')) {
    // Set the Content-Encoding header for Gzip files
    res.setHeader('Content-Encoding', 'gzip');
  }
  next();
});

// Serve static files with the correct headers
app.use(serveStatic(path.join(__dirname), {
  setHeaders: (res, filePath) => {
    // Set Content-Type headers for different file types
    if (filePath.endsWith('.wasm.gz')) {
      console.log("wasm");
      res.setHeader('Content-Type', 'application/wasm');
      res.setHeader('Content-Encoding', 'gzip');
    } else if (filePath.endsWith('.js.gz')) {
      res.setHeader('Content-Type', 'application/javascript');
      res.setHeader('Content-Encoding', 'gzip');
    } else if (filePath.endsWith('.css')) {
      res.setHeader('Content-Type', 'text/css');
    } else if (filePath.endsWith('.html')) {
      res.setHeader('Content-Type', 'text/html');
    }
  }
}));

// Start the server
app.listen(80, '0.0.0.0',() => {
  console.log('Server has started on port 80!');
});
